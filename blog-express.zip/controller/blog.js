const {exec , escape} = require('../db/mysql');
const xss = require('xss');

const getList = (author,keywork)=>{
    //1=1有特殊作用，防止参数为空
    let sql = `select * from blogs where 1=1 and state = 0`;
    if(author){
        sql += ` and author="${author}"`
    }
    if(keywork){
        sql += ` and title like "%${keywork}%"`
    }
    sql += ` order by createtime desc;`
    return exec(sql);
}

const getDtail = (id)=>{

    //1=1有特殊作用，防止参数为空
    let sql = `select * from blogs where 1=1`;
    if(id){
        sql += ` and id=${id}`  
    }
    return exec(sql);
}

const newBlog = (blogData)=>{
    let {title,content,author} = blogData;
    title = escape(xss(title));
    content = xss(content);
    author = xss(author);
    const createtime = Date.now();
    let sql = `insert into blogs (title,content,createtime,author) values (${title},"${content}",${createtime},"${author}");`;
    
    //数据库中的id
    return exec(sql);

}

const updateBlog= (id,blogData = {})=>{
    
    let {title,content,author} = blogData;
    title = escape(xss(title));
    content = xss(content);
    author = xss(author);

    console.log(`更新一篇博客, ID:${id}, 内容:${blogData}`);
    if(id){
        let sql = `update blogs set `;
        if(title){
            sql += ` title="${title}" `;
        }
        if(content){
            sql += `, content="${content}" `;
        }
        if(author){
            sql += `, author="${author}" `
        }
        sql += ` where id = ${id}; `;
        //createtime ， 自己考虑下改不改。
        return exec(sql).then(sqlDate =>{
            console.log("blog undata",sqlDate);
            if(sqlDate.affectedRows>=1){
                return true;
            }else{
                return false;
            }
            
        })
    }
}

const delBlog = (id,author)=>{
    console.log(`删除一篇博客, ID:${id}`);
    let sql = ` update blogs set state = 1 where 1 = 1 and id=${id} and author = "${author}";`;
    return exec(sql).then(sqlDate =>{
        if(sqlDate.affectedRows>=1){
            return true;
        }else{
            return false;
        }
    })
}

module.exports={
    getList,
    getDtail,
    newBlog,
    updateBlog,
    delBlog
}
